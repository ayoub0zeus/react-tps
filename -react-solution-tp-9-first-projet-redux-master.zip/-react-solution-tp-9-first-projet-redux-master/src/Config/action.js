export const Incrementer = () => {
    return {type:"Incrementer"}
}
export const Decrementer = () => {
    return {type:"Decrementer"}
}
export const Reset = () => {
    return {type:"Reset"}
}